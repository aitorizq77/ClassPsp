package PacoSumadorRestador;
public class Sumador extends Thread {

    private Contador contador;

    public Sumador(Contador contador) {
        this.contador = contador;
    }

    @Override
    public void run() {

        for (int i = 0; i < 10; i++) {
            contador.sumar();
        }
    }
}