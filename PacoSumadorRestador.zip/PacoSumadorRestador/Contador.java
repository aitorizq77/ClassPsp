package PacoSumadorRestador;

public class Contador {

    private int valor = 0;
    private boolean turnoSumador = true;

    public synchronized void sumar() {

        while (!turnoSumador) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }

        valor++;
        System.out.println("Sumador: " + valor);

        turnoSumador = false;
        notifyAll();
    }

    public synchronized void restar() {

        while (turnoSumador) {
            try {
                wait();
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                return;
            }
        }

        valor--;
        System.out.println("Restador: " + valor);

        turnoSumador = true;
        notifyAll();
    }

    public synchronized int getValor() {
        return valor;
    }
}