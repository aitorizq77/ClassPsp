package PacoSumadorRestador;
public class main {

    public static void main(String[] args) {

        Contador contador = new Contador();

        Sumador sumador = new Sumador(contador);
        Restador restador = new Restador(contador);

        sumador.start();
        restador.start();

        try {
            sumador.join();
            restador.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        System.out.println("Valor final: " + contador.getValor());
    }
}