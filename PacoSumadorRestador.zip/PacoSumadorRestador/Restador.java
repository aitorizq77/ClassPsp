package PacoSumadorRestador;

public class Restador extends Thread {

    private Contador contador;

    public Restador(Contador contador) {
        this.contador = contador;
    }

    @Override
    public void run() {

        for (int i = 0; i < 10; i++) {
            contador.restar();
        }
    }
}